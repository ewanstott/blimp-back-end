const salt = `ch16-back-end`;

module.exports = { salt };
